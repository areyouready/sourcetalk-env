/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* @version $Id: java.c 1196468 2011-11-02 06:24:11Z mturk $ */
#include "jsvc.h"

#ifdef OS_CYGWIN
typedef long long __int64;
#endif
#include <unistd.h>
#include <jni.h>

#ifdef CHARSET_EBCDIC
#ifdef OSD_POSIX
#include <ascii_ebcdic.h>
#define jsvc_xlate_to_ascii(b) _e2a(b)
#define jsvc_xlate_from_ascii(b) _a2e(b)
#endif
#else
#define jsvc_xlate_to_ascii(b)  /* NOOP */
#define jsvc_xlate_from_ascii(b)        /* NOOP */
#endif

static JavaVM *jvm = NULL;
static JNIEnv *env = NULL;
static jclass cls  = NULL;

#define FALSE 0
#define TRUE !FALSE

static void shutdown(JNIEnv *env, jobject source, jboolean reload)
{
    log_debug("Shutdown requested (reload is %d)", reload);
    if (reload == TRUE)
        main_reload();
    else
        main_shutdown();
}

static void failed(JNIEnv *env, jobject source, jstring message)
{
    if (message) {
        const char *msg = (*env)->GetStringUTFChars(env, message, NULL);
        log_error("Failed %s", msg ? msg : "(null)");
        if (msg)
            (*env)->ReleaseStringUTFChars(env, message, msg);
    }
    else
        log_error("Failed requested");
    main_shutdown();
}

/* Automatically restart when the JVM crashes */
static void java_abort123(void)
{
    exit(123);
}

char *java_library(arg_data *args, home_data *data)
{
    char *libf = NULL;

    /* Did we find ANY virtual machine? */
    if (data->jnum == 0) {
        log_error("Cannot find any VM in Java Home %s", data->path);
        return NULL;
    }

    /* Select the VM */
    if (args->name == NULL) {
        libf = data->jvms[0]->libr;
        log_debug("Using default JVM in %s", libf);
    }
    else {
        int x;
        for (x = 0; x < data->jnum; x++) {
            if (data->jvms[x]->name == NULL)
                continue;
            if (strcmp(args->name, data->jvms[x]->name) == 0) {
                libf = data->jvms[x]->libr;
                log_debug("Using specific JVM in %s", libf);
                break;
            }
        }
        if (libf == NULL) {
            log_error("Invalid JVM name specified %s", args->name);
            return NULL;
        }
    }
    return libf;
}

typedef jint (*jvm_create_t)(JavaVM **, JNIEnv **, JavaVMInitArgs *);

bool java_signal(void)
{
    jmethodID method;
    jboolean ret;
    char start[] = "signal";
    char startparams[] = "()Z";

    jsvc_xlate_to_ascii(start);
    jsvc_xlate_to_ascii(startparams);
    method = (*env)->GetStaticMethodID(env, cls, start, startparams);
    if (method == NULL) {
        (*env)->ExceptionClear(env);
        log_error("Cannot find DaemonLoader \"signal\" method");
        return false;
    }

    ret = (*env)->CallStaticBooleanMethod(env, cls, method);
    /* Clear any pending exception
     * so we can continue calling native methods
     */
    (*env)->ExceptionClear(env);
    log_debug("Daemon signal method returned %s", ret ? "true" : "false");
    return ret;
}

/* Initialize the JVM and its environment, loading libraries and all */
bool java_init(arg_data *args, home_data *data)
{
#ifdef OS_DARWIN
    dso_handle apph = NULL;
    char appf[1024];
    struct stat sb;
#endif /* ifdef OS_DARWIN */
    jvm_create_t symb = NULL;
    JNINativeMethod nativemethods[2];
    JavaVMOption *opt = NULL;
    dso_handle libh   = NULL;
    JavaVMInitArgs arg;
    char *libf = NULL;
    jint ret;
    int x;
    char loaderclass[]    = LOADER;
    char shutdownmethod[] = "shutdown";
    char shutdownparams[] = "(Z)V";
    char failedmethod[]   = "failed";
    char failedparams[]   = "(Ljava/lang/String;)V";
    char daemonprocid[64];
    /* Decide WHAT virtual machine we need to use */
    libf = java_library(args, data);
    if (libf == NULL) {
        log_error("Cannot locate JVM library file");
        return false;
    }

    /* Initialize the DSO library */
    if (dso_init() != true) {
        log_error("Cannot initialize the dynamic library loader");
        return false;
    }

    /* Load the JVM library */
#if !defined(OSD_POSIX)
    libh = dso_link(libf);
    if (libh == NULL) {
        log_error("Cannot dynamically link to %s", libf);
        log_error("%s", dso_error());
        return false;
    }
    log_debug("JVM library %s loaded", libf);
#endif

#ifdef OS_DARWIN
    /*
       MacOS/X actually has two libraries, one with the REAL vm, and one for
       the VM startup.
       before JVM 1.4.1 The first one (libappshell.dyld) contains CreateVM
       JVM 1.4.1 through 1.5.* The library name is libjvm_compat.dylib
       starting with JVM 1.6 on OS X 10.6 the library name is libverify.dylib.
     */
    if (replace(appf, 1024, "$JAVA_HOME/../Libraries/libappshell.dylib",
                "$JAVA_HOME", data->path) != 0) {
        log_error("Cannot replace values in loader library");
        return false;
    }
    if (stat(appf, &sb)) {
        if (replace(appf, 1024, "$JAVA_HOME/../Libraries/libjvm_compat.dylib",
                    "$JAVA_HOME", data->path) != 0) {
            log_error("Cannot replace values in loader library");
            return false;
        }
    }
    if (stat(appf, &sb)) {
        if (replace(appf, 1024, "$JAVA_HOME/../Libraries/libverify.dylib",
                    "$JAVA_HOME", data->path) != 0) {
            log_error("Cannot replace values in loader library");
            return false;
        }
    }
    apph = dso_link(appf);
    if (apph == NULL) {
        log_error("Cannot load required shell library %s", appf);
        return false;
    }
    log_debug("Shell library %s loaded", appf);
#endif /* ifdef OS_DARWIN */
#if defined(OSD_POSIX)
    /* BS2000 does not allow to call JNI_CreateJavaVM indirectly */
#else
    symb = (jvm_create_t)dso_symbol(libh, "JNI_CreateJavaVM");
    if (symb == NULL) {
#ifdef OS_DARWIN
        symb = (jvm_create_t)dso_symbol(apph, "JNI_CreateJavaVM");
        if (symb == NULL) {
#endif /* ifdef OS_DARWIN */
            log_error("Cannot find JVM library entry point");
            return false;
#ifdef OS_DARWIN
        }
#endif /* ifdef OS_DARWIN */
    }
    log_debug("JVM library entry point found (0x%08X)", symb);
#endif

    /* Prepare the VM initialization arguments */

    /*
     * Mac OS X Java will load JVM 1.3.1 instead of 1.4.2 if JNI_VERSION_1_2
     * is specified. So use JNI_VERSION_1_4 if we can.
     */
#if defined(JNI_VERSION_1_4)
    arg.version = JNI_VERSION_1_4;
#else
    arg.version = JNI_VERSION_1_2;
#endif
#if defined(OSD_POSIX)
    if (JNI_GetDefaultJavaVMInitArgs(&arg) < 0) {
        log_error("Cannot init default JVM default args");
        return false;
    }
#endif
    arg.ignoreUnrecognized = FALSE;
    arg.nOptions = args->onum + 4; /* pid, ppid and abort */
    opt = (JavaVMOption *) malloc(arg.nOptions * sizeof(JavaVMOption));
    for (x = 0; x < args->onum; x++) {
        opt[x].optionString = strdup(args->opts[x]);
        jsvc_xlate_to_ascii(opt[x].optionString);
        opt[x].extraInfo = NULL;
    }
    /* Add our daemon process id */
    snprintf(daemonprocid, sizeof(daemonprocid),
             "-Dcommons.daemon.process.id=%d", (int)getpid());
    opt[x].optionString = strdup(daemonprocid);
    jsvc_xlate_to_ascii(opt[x].optionString);
    opt[x++].extraInfo  = NULL;
    snprintf(daemonprocid, sizeof(daemonprocid),
             "-Dcommons.daemon.process.parent=%d", (int)getppid());
    opt[x].optionString = strdup(daemonprocid);
    jsvc_xlate_to_ascii(opt[x].optionString);
    opt[x++].extraInfo  = NULL;
    snprintf(daemonprocid, sizeof(daemonprocid),
             "-Dcommons.daemon.version=%s", JSVC_VERSION_STRING);
    opt[x].optionString = strdup(daemonprocid);
    jsvc_xlate_to_ascii(opt[x].optionString);
    opt[x++].extraInfo  = NULL;
    opt[x].optionString = strdup("abort");
    jsvc_xlate_to_ascii(opt[x].optionString);
    opt[x].extraInfo = (void *)java_abort123;
    arg.options = opt;

    /* Do some debugging */
    if (log_debug_flag == true) {
        log_debug("+-- DUMPING JAVA VM CREATION ARGUMENTS -----------------");
        log_debug("| Version:                       %#08x", arg.version);
        log_debug("| Ignore Unrecognized Arguments: %s",
                  arg.ignoreUnrecognized == TRUE ? "True" : "False");
        log_debug("| Extra options:                 %d", args->onum);

        for (x = 0; x < args->onum; x++) {
            jsvc_xlate_from_ascii(opt[x].optionString);
            log_debug("|   \"%s\" (0x%08x)", opt[x].optionString,
                      opt[x].extraInfo);
            jsvc_xlate_to_ascii(opt[x].optionString);
        }
        log_debug("+-------------------------------------------------------");
        log_debug("| Internal options:              %d", arg.nOptions - args->onum);

        for (; x < arg.nOptions; x++) {
            jsvc_xlate_from_ascii(opt[x].optionString);
            log_debug("|   \"%s\" (0x%08x)", opt[x].optionString,
                      opt[x].extraInfo);
            jsvc_xlate_to_ascii(opt[x].optionString);
        }
        log_debug("+-------------------------------------------------------");
    }

    /* And finally create the Java VM */
#if defined(OSD_POSIX)
    ret = JNI_CreateJavaVM(&jvm, &env, &arg);
#else
    ret = (*symb) (&jvm, &env, &arg);
#endif
    if (ret < 0) {
        log_error("Cannot create Java VM");
        return false;
    }
    log_debug("Java VM created successfully");

    jsvc_xlate_to_ascii(loaderclass);
    cls = (*env)->FindClass(env, loaderclass);
    jsvc_xlate_from_ascii(loaderclass);
    if (cls == NULL) {
        log_error("Cannot find daemon loader %s", loaderclass);
        return false;
    }
    log_debug("Class %s found", loaderclass);

    jsvc_xlate_to_ascii(shutdownmethod);
    nativemethods[0].name = shutdownmethod;
    jsvc_xlate_to_ascii(shutdownparams);
    nativemethods[0].signature = shutdownparams;
    nativemethods[0].fnPtr = (void *)shutdown;
    jsvc_xlate_to_ascii(failedmethod);
    nativemethods[1].name = failedmethod;
    jsvc_xlate_to_ascii(failedparams);
    nativemethods[1].signature = failedparams;
    nativemethods[1].fnPtr = (void *)failed;

    if ((*env)->RegisterNatives(env, cls, nativemethods, 2) != 0) {
        log_error("Cannot register native methods");
        return false;
    }
    log_debug("Native methods registered");

    return true;
}

/* Destroy the Java VM */
bool JVM_destroy(int exit)
{
    jclass system = NULL;
    jmethodID method;
    char System[] = "java/lang/System";
    char exitclass[] = "exit";
    char exitparams[] = "(I)V";

    jsvc_xlate_to_ascii(System);
    system = (*env)->FindClass(env, System);
    jsvc_xlate_from_ascii(System);
    if (system == NULL) {
        log_error("Cannot find class %s", System);
        return false;
    }

    jsvc_xlate_to_ascii(exitclass);
    jsvc_xlate_to_ascii(exitparams);
    method = (*env)->GetStaticMethodID(env, system, exitclass, exitparams);
    if (method == NULL) {
        log_error("Cannot find \"System.exit(int)\" entry point");
        return false;
    }

    log_debug("Calling System.exit(%d)", exit);
    (*env)->CallStaticVoidMethod(env, system, method, (jint) exit);

    /* We shouldn't get here, but just in case... */
    log_debug("Destroying the Java VM");
    if ((*jvm)->DestroyJavaVM(jvm) != 0)
        return false;
    log_debug("Java VM destroyed");
    return true;
}

/* Call the load method in our DaemonLoader class */
bool java_load(arg_data *args)
{
    jclass stringClass       = NULL;
    jstring className        = NULL;
    jstring currentArgument  = NULL;
    jobjectArray stringArray = NULL;
    jmethodID method         = NULL;
    jboolean ret             = FALSE;
    int x;
    char lang[] = "java/lang/String";
    char load[] = "load";
    char loadparams[] = "(Ljava/lang/String;[Ljava/lang/String;)Z";

    jsvc_xlate_to_ascii(args->clas);
    className = (*env)->NewStringUTF(env, args->clas);
    jsvc_xlate_from_ascii(args->clas);
    if (className == NULL) {
        log_error("Cannot create string for Class   iframs[] = "(Lpti @param path The java home path sptcl|A                     
tions of VMs and OSes. If i-2.0
 
   Unless required by applicable lALSE;
    int x;
Cannot create string for Class   ifrtArgument  = N_ascii(argsOring curre    classNama   , java home penv)->GetStris of VMs aent  = cii(args->clas);
    if (className == NULL)   /* Prepant  
Cannot create string for Class   ifr         %d", args->onam);

        for (x String;[Ljava/lang/String;trin[x].optionStrilassName        to_ascii(args->clas);
    classNamtrin[x].optionStric_xlaassName        t      }
        }
    >NewStringUTF(env, args->clatrin[x].optionStri);
    if (className == NULL) {
           /* Prog_error("Intrin[x].optionStri);
 es in loader library");
        _ascii(aSetOring curreEoduleFt);
   VMs aent  , x,ilassName       )r Class   iframs[] = "(Lpti @paramtdown requams[] = "(Lpti @paramtdotart);
    jsvc_xlate_to_ascii(startparams);
    method = mtdo, mtdotart);
    jssystem, exitclass, exitparams);
    if (method == NULExcepti       lomtdorror("Cannot find \"System.exit(int)\" entry point");
        D) {
      n-nu..se;
    log        return false;
    }

    ret = (*env)->Call,jsvc_xlate"%s\" (0x%08x)", opt[x]..................... VMs aent  wn requested   t  ULL;
dso_link(appf);
    if (apph == NULL) {
 ind \"System.exit(int)\" entry point");
        D) {
      ;
    }
    log_debstem.exit(iug("Java VM destroyedn_shut   return trueL) {
        lad method in n_shuJavaVMInitArgs *);

bool java_signal(void)
{
    jmethodID method;
   methlean ret;
    char start[] = "signal";
    char startparams[] = "()Z";

    jsvc_xlate_to_ascii(start);
    jsvc_xlate_to_ascii(startparams);
    method = (*env)->GetStaticMethodID(env, cls, start, startparams);
    if (method == NULExcepti       lo>GetSrror("Cannot find \"System.exit(int)\" entry point");
        return false;
    }

    ret = (*env)->CallStaticBested   t  ULL;
dso_link(appf);
    if (apph =n_shutL) {
 ind \"System.exit(int)\" entry point");
        D) {
  n_shu;
    }
    log_debstem.exit(iug("Java VMails (stroyed "/ussleep_POSprWe nt are lvocaS/X actA_HOM optional d in nleeptroy wae Java VM */
bool*enTtA_HOint exit)
{
    jclass system = Njnleepod;
   leep" system = Njnleepr start[] = "Jledparams[]   jctA_HO   = FALSE;
    TtA_HOgnal";
    char startparams[jnleep()Z";

    jsvc_xlate_to_asjnleepr star()Z";

    jsvc_xlate_to_asjctA_HOhod(env,*enTtA_HOath sptcl|A               jctA_HOhodticBeste*enTtA_HOattart, startparams);
    if (method == NULALSE;
    TtA_HOjsvc_xind \"System.exit(tive methodsvc_xlate_to_ascii(startparams);
    method TtA_HO,Njnleep, jnleepr star()Z";

(env, cls, start, startparams);
    if (method ==ibraryyednleep_r("Cannot find \"System.exit( entry point"alling System.exit(%d)", exit);
  od TtA_HO,N->CallStatc.h") wae ils1000)Java VM destroyedn_opt   return trueL) {
        lad method in n_opJavaVMInitArgs *);

bool java_signal(void)
{
    jmethodID mopod;
   mop"  jmethodID mopr start[] = "signal";
    char startparams[] op()Z";

    jsvc_xlate_to_as mopr star
    jsvc_xlate_to_ascii(startparams);
    method = (*op,  mopr star
    js(env, cls, start, startparams);
    if (method ==ibrarExcepti       lo>Goprror("Cannot find \"System.exit(int)\" entry point");
        return false;
    }

    ret = (*env)->CallStaticBested   t  ULL;
dso_link(appf);
    if (apph =n_optL) {
 ind \"System.exit(int)\" entry point");
        D) {
  n_opr;
    }
    log_debstem.exit(iug("Java VM destroyedon = JNI   return trueL) {
        lad method in on = JNJavaVMInitArgs *);

bool java_signahodIDon = JNt[] = on = JN"_signahodIDon = JNr start[] = "s"exit";
    char exitparams[]:                char exitparams[]:      r star
    jsvc_xlate_to_ascii(startparams);
    method = :      , :      r star
    js(env, cls, start, startparams);
    if (method ==ibrarExcepti       lo:      rror("Cannot find \"System.exit(int)\" entry point"alling System.exit(%d)", exit);
  od v)->CallStaticB.exit(iug("Java VM destroyedcadd =   return true;
}

/* Call the load method in cadd DaemonLoader class */
bolass stringClass  NULL;
    jobjectArray strin NULL;
    jmethodID meth NULL;
    jbhodIDcadd t[] = cadd "    jbhodIDcadd  char load[] = "load";
    charsignal";
 );
        radd jvms[) {
 ind lang/String;[Ljava/lang/String;)Z";

    jsvc_xlate_to_ascii(args->clas);
    className = (*env)->NewStringUTF(env, args->clas);
    jsvc_xlate_from_ascii(args->clas);
    if (className == NULL) {
        log_error("Cannot create string for Class   iframs[] ;[Ljava/lang/Scadd           char exitparams[]cadd  char 
    jsvc_xlate_to_ascii(startparams);
    method = cadd , cadd  char 
    js(env, cls, start, startparams);
    if (method ==ibrarExcepti       locadd rror("Cannot find \"System.exit(int)\" entry point");
        return false;
    }

    ret = (*env)->Call,jsvc_xlateStaticBested   t  ULL;
dso_link(appf);
    if Anmber, messadetecu;
 cadd jvmsoyed%ss[) {
 iclassName = (*env)-stem.exit(int)\" entry point");
        D) {
  cadd ;
    }
    log_debstem.exit(iug("Java VM destroyedeturn fI   return trueL) {
        lad method in 
/* DestavaVMInitArgs *);

bool java_signal(void)
{
    jmethodID
/* Desload[]
/* Des"  jmethodID
/* Desr start[] = "signal";
    char startparams[
/* Des          char exitparams[]
/* Desr star
    jsvc_xlate_to_ascii(startparams);
    method = 
/* Des, 
/* Desr star
    js(env, cls, start, startparams);
    if (method ==ibrarExcepti       lo
/* Desrror("Cannot find \"System.exit(int)\" entry point");
        return false;
    }

    ret = (*env)->CallStaticBested   t  ULL;
dso_link(appf);
    if (apph =eturn fIL) {
 ind \"System.exit(int)\" entry point");
        D) {
  eturn fal    }
    log_debstem.exit(iug("Java                                     